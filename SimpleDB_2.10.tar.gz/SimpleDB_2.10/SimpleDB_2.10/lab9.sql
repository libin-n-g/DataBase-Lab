CREATE USER 'A'@'%';
CREATE USER 'B'@'%';

GRANT LOCK TABLES ON University.* TO A;
GRANT LOCK TABLES ON University.* TO B;

/*USER A */

LOCK TABLE student WRITE WAIT ;




/*USER B */
LOCK TABLE instructor WRITE WAIT ;
